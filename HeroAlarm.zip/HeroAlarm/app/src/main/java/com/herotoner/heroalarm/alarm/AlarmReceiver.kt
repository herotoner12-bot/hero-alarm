package com.herotoner.heroalarm.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.core.content.ContextCompat
import com.herotoner.heroalarm.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra(AlarmScheduler.EXTRA_ID, -1L)
        val trigger = intent.getLongExtra(AlarmScheduler.EXTRA_TIME, 0L)
        if (id < 0) return
        val app = context.applicationContext
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = AppDatabase.get(app).dao()
                val a = dao.get(id)
                if (a != null && a.enabled) {
                    // Duplicate guard: never ring twice for the same scheduled moment.
                    if (a.lastFiredAt != trigger) {
                        dao.setLastFired(id, trigger)
                        ContextCompat.startForegroundService(
                            app, Intent(app, AlarmService::class.java).putExtra(AlarmScheduler.EXTRA_ID, id)
                        )
                    }
                    if (a.daysMask == 0) {
                        dao.update(a.copy(enabled = false, lastFiredAt = trigger, nextTrigger = 0))
                    } else {
                        AlarmScheduler.scheduleAndStore(app, dao, a.copy(lastFiredAt = trigger))
                    }
                }
            } catch (e: Exception) {
                Log.e("HeroAlarm", "alarm receiver failed", e)
            } finally {
                pending.finish()
            }
        }
    }
}
