package com.herotoner.heroalarm.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.herotoner.heroalarm.MainActivity
import com.herotoner.heroalarm.data.Alarm
import com.herotoner.heroalarm.data.AlarmDao
import com.herotoner.heroalarm.data.AlarmLog
import com.herotoner.heroalarm.data.AppDatabase
import java.util.Calendar

object AlarmScheduler {
    const val EXTRA_ID = "alarm_id"
    const val EXTRA_TIME = "trigger_time"
    private const val TAG = "HeroAlarm"

    private val IMMUTABLE = if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0

    private fun firePending(ctx: Context, id: Long, trigger: Long): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java)
            .putExtra(EXTRA_ID, id).putExtra(EXTRA_TIME, trigger)
        return PendingIntent.getBroadcast(ctx, id.toInt(), i, PendingIntent.FLAG_UPDATE_CURRENT or IMMUTABLE)
    }

    /** Registers the next occurrence with AlarmManager and stores it. Returns the trigger time (0 if disabled). */
    suspend fun scheduleAndStore(ctx: Context, dao: AlarmDao, a: Alarm): Long {
        if (!a.enabled) { cancel(ctx, a.id); dao.setNextTrigger(a.id, 0); return 0 }
        val t = AlarmTime.nextTrigger(a.hour, a.minute, a.daysMask, Calendar.getInstance())
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val fire = firePending(ctx, a.id, t)
        val show = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or IMMUTABLE
        )
        try {
            // setAlarmClock needs no exact-alarm permission and is exempt from Doze and background-start limits.
            am.setAlarmClock(AlarmManager.AlarmClockInfo(t, show), fire)
        } catch (e: Exception) {
            Log.w(TAG, "setAlarmClock failed, falling back", e)
            am.set(AlarmManager.RTC_WAKEUP, t, fire)
        }
        dao.setNextTrigger(a.id, t)
        return t
    }

    fun cancel(ctx: Context, id: Long) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(firePending(ctx, id, 0))
    }

    /**
     * Re-registers every enabled alarm (after boot, time or timezone change, app update, app start).
     * With [markMissed], one-time alarms whose time passed while the TV was off are switched off and logged
     * instead of being pushed to tomorrow.
     */
    suspend fun restoreAll(ctx: Context, markMissed: Boolean) {
        val dao = AppDatabase.get(ctx).dao()
        val now = System.currentTimeMillis()
        for (a in dao.getAll()) {
            if (!a.enabled) continue
            if (markMissed && a.daysMask == 0 && a.nextTrigger in 1 until now) {
                dao.update(a.copy(enabled = false, nextTrigger = 0))
                dao.insertLog(AlarmLog(alarmId = a.id, title = a.title, firedAt = a.nextTrigger, dismissedAt = now, status = "MISSED"))
                continue
            }
            scheduleAndStore(ctx, dao, a)
        }
    }
}
