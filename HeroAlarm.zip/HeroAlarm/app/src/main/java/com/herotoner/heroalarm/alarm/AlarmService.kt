package com.herotoner.heroalarm.alarm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.util.Log
import android.view.KeyEvent
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.herotoner.heroalarm.AlarmActivity
import com.herotoner.heroalarm.R
import com.herotoner.heroalarm.data.Alarm
import com.herotoner.heroalarm.data.AlarmLog
import com.herotoner.heroalarm.data.AlarmStore
import com.herotoner.heroalarm.data.AppDatabase
import com.herotoner.heroalarm.ui.SOUND_RES
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Plays the alarm sound (one at a time), requests transient audio focus and sends a media "pause" key so that
 * players such as YouTube pause, and shows the full-screen alarm UI. Pausing is best-effort: it depends on the
 * player app honouring audio focus / media keys.
 */
class AlarmService : Service() {

    companion object {
        val ringing = MutableStateFlow(false)
        const val ACTION_STOP = "com.herotoner.heroalarm.ACTION_STOP"
        private const val CHANNEL = "hero_alarm_channel"
        private const val NOTIF_ID = 1001
        private const val TIMEOUT_MS = 10 * 60 * 1000L
        private const val TAG = "HeroAlarm"
        private val IMMUTABLE = if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
    }

    private var player: MediaPlayer? = null
    private var focusRequest: AudioFocusRequest? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var logId = 0L
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())
    private val timeoutRunnable = Runnable { stopAlarm("TIMEOUT") }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopAlarm("DISMISSED")
            return START_NOT_STICKY
        }
        val id = intent?.getLongExtra(AlarmScheduler.EXTRA_ID, -1L) ?: -1L
        createChannel()
        goForeground(buildNotification(getString(R.string.app_name), "", id))

        if (ringing.value) return START_NOT_STICKY // only one alarm sound at a time
        ringing.value = true

        scope.launch {
            val alarm = withContext(Dispatchers.IO) {
                try { AlarmStore.load(applicationContext, id) } catch (e: Exception) { null }
            }
            if (alarm == null) { stopAlarm(null); return@launch }
            if (!ringing.value) return@launch // stopped while loading
            begin(alarm)
        }
        return START_NOT_STICKY
    }

    private suspend fun begin(a: Alarm) {
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .notify(NOTIF_ID, buildNotification(a.title, a.description, a.id))
        acquireWakeLock()
        requestFocusAndPause()
        startSound(a)
        launchActivity(a.id)
        handler.postDelayed(timeoutRunnable, TIMEOUT_MS)
        if (a.id != com.herotoner.heroalarm.data.TEST_ALARM_ID) {
            logId = withContext(Dispatchers.IO) {
                AppDatabase.get(applicationContext).dao().insertLog(
                    AlarmLog(alarmId = a.id, title = a.title, firedAt = System.currentTimeMillis(), status = "RINGING")
                )
            }
        }
    }

    private fun startSound(a: Alarm) {
        releasePlayer()
        try {
            val res = SOUND_RES.getOrElse(a.soundIndex) { SOUND_RES[0] }
            val v = (a.volume.coerceIn(0, 100)) / 100f
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIC).build()
            )
            resources.openRawResourceFd(res).use { afd ->
                mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            }
            mp.isLooping = true
            mp.setVolume(v, v)
            mp.prepare()
            mp.start()
            player = mp
        } catch (e: Exception) {
            Log.e(TAG, "could not play alarm sound", e)
        }
    }

    private fun requestFocusAndPause() {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIC).build()
                focusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                    .setAudioAttributes(attrs).setOnAudioFocusChangeListener { }.build()
                am.requestAudioFocus(focusRequest!!)
            } else {
                @Suppress("DEPRECATION")
                am.requestAudioFocus(null, AudioManager.STREAM_ALARM, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
            }
            // Public API: sends a media key to the current active media session (best effort).
            val t = SystemClock.uptimeMillis()
            am.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PAUSE, 0))
            am.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PAUSE, 0))
        } catch (e: Exception) {
            Log.w(TAG, "audio focus / pause failed", e)
        }
    }

    private fun abandonFocus() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (Build.VERSION.SDK_INT >= 26) focusRequest?.let { am.abandonAudioFocusRequest(it) }
            else @Suppress("DEPRECATION") am.abandonAudioFocus(null)
        } catch (e: Exception) { Log.w(TAG, "abandon focus failed", e) }
        focusRequest = null
    }

    private fun releasePlayer() {
        player?.let {
            try { if (it.isPlaying) it.stop() } catch (_: Exception) {}
            try { it.release() } catch (_: Exception) {}
        }
        player = null
    }

    private fun acquireWakeLock() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "HeroAlarm:ring")
                .apply { acquire(TIMEOUT_MS + 5_000) }
        } catch (e: Exception) { Log.w(TAG, "wakelock failed", e) }
    }

    private fun launchActivity(id: Long) {
        try {
            startActivity(
                Intent(this, AlarmActivity::class.java)
                    .putExtra(AlarmScheduler.EXTRA_ID, id)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_USER_ACTION)
            )
        } catch (e: Exception) {
            // Background start can be blocked on some versions; the full-screen notification is the fallback.
            Log.w(TAG, "direct activity start blocked", e)
        }
    }

    private fun stopAlarm(status: String?) {
        handler.removeCallbacks(timeoutRunnable)
        releasePlayer()
        abandonFocus()
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        wakeLock = null
        ringing.value = false
        val lid = logId
        logId = 0
        if (status != null && lid != 0L) {
            val app = applicationContext
            CoroutineScope(Dispatchers.IO).launch {
                try { AppDatabase.get(app).dao().finishLog(lid, System.currentTimeMillis(), status) } catch (_: Exception) {}
            }
        }
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacks(timeoutRunnable)
        releasePlayer()
        abandonFocus()
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        ringing.value = false
        scope.cancel()
        super.onDestroy()
    }

    private fun goForeground(n: Notification) {
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0
        ServiceCompat.startForeground(this, NOTIF_ID, n, type)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL) == null) {
            val ch = NotificationChannel(CHANNEL, "HERO ALARM", NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(null, null)
            ch.enableVibration(false)
            nm.createNotificationChannel(ch)
        }
    }

    private fun buildNotification(title: String, text: String, id: Long): Notification {
        val act = Intent(this, AlarmActivity::class.java)
            .putExtra(AlarmScheduler.EXTRA_ID, id)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val full = PendingIntent.getActivity(this, 1, act, PendingIntent.FLAG_UPDATE_CURRENT or IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 2, Intent(this, AlarmService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_bell)
            .setContentTitle(title)
            .setContentText(text.ifEmpty { null })
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setContentIntent(full)
            .setFullScreenIntent(full, true)
            .addAction(0, "إيقاف المنبّه", stop)
            .build()
    }
}
