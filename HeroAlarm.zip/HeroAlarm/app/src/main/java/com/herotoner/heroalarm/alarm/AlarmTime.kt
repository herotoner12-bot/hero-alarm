package com.herotoner.heroalarm.alarm

import java.util.Calendar

/** Pure time logic, unit-tested without Android. */
object AlarmTime {
    /** Next moment strictly after [now] that matches hour:minute and the repeat mask (0 = any day). */
    fun nextTrigger(hour: Int, minute: Int, daysMask: Int, now: Calendar): Long {
        val c = now.clone() as Calendar
        c.set(Calendar.HOUR_OF_DAY, hour.coerceIn(0, 23))
        c.set(Calendar.MINUTE, minute.coerceIn(0, 59))
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        repeat(8) {
            if (c.timeInMillis > now.timeInMillis) {
                val dayBit = 1 shl (c.get(Calendar.DAY_OF_WEEK) - 1)
                if (daysMask == 0 || (daysMask and dayBit) != 0) return c.timeInMillis
            }
            c.add(Calendar.DAY_OF_YEAR, 1)
        }
        return c.timeInMillis
    }
}
