package com.herotoner.heroalarm.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AlarmDao {
    @Query("SELECT * FROM alarms ORDER BY hour, minute")
    fun observeAll(): Flow<List<Alarm>>

    @Query("SELECT * FROM alarms")
    suspend fun getAll(): List<Alarm>

    @Query("SELECT * FROM alarms WHERE id = :id")
    suspend fun get(id: Long): Alarm?

    @Insert suspend fun insert(alarm: Alarm): Long
    @Update suspend fun update(alarm: Alarm)

    @Query("DELETE FROM alarms WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("UPDATE alarms SET enabled = 0")
    suspend fun disableAll()

    @Query("UPDATE alarms SET lastFiredAt = :t WHERE id = :id")
    suspend fun setLastFired(id: Long, t: Long)

    @Query("UPDATE alarms SET nextTrigger = :t WHERE id = :id")
    suspend fun setNextTrigger(id: Long, t: Long)

    @Insert suspend fun insertLog(log: AlarmLog): Long

    @Query("UPDATE alarm_logs SET dismissedAt = :t, status = :status WHERE id = :id")
    suspend fun finishLog(id: Long, t: Long, status: String)
}
