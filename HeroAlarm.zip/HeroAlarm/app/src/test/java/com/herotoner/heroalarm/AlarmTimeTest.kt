package com.herotoner.heroalarm

import com.herotoner.heroalarm.alarm.AlarmTime
import java.util.Calendar
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AlarmTimeTest {
    private fun cal(y: Int, mo: Int, d: Int, h: Int, mi: Int) = Calendar.getInstance().apply {
        clear(); set(y, mo, d, h, mi, 0)
    }

    @Test fun oneTimeLaterToday() {
        val now = cal(2026, Calendar.NOVEMBER, 9, 6, 0)
        val t = Calendar.getInstance().apply { timeInMillis = AlarmTime.nextTrigger(7, 30, 0, now) }
        assertEquals(9, t.get(Calendar.DAY_OF_MONTH)); assertEquals(7, t.get(Calendar.HOUR_OF_DAY)); assertEquals(30, t.get(Calendar.MINUTE))
    }

    @Test fun oneTimePassedGoesToTomorrow() {
        val now = cal(2026, Calendar.NOVEMBER, 9, 8, 0)
        val t = Calendar.getInstance().apply { timeInMillis = AlarmTime.nextTrigger(7, 30, 0, now) }
        assertEquals(10, t.get(Calendar.DAY_OF_MONTH))
    }

    @Test fun exactlyNowIsNotReturned() {
        val now = cal(2026, Calendar.NOVEMBER, 9, 7, 30)
        assertTrue(AlarmTime.nextTrigger(7, 30, 0, now) > now.timeInMillis)
    }

    @Test fun repeatingPicksNextMatchingWeekday() {
        // 2026-11-09 is a Monday. Mask = Friday only (Calendar.FRIDAY = 6 -> bit 5).
        val now = cal(2026, Calendar.NOVEMBER, 9, 9, 0)
        val t = Calendar.getInstance().apply { timeInMillis = AlarmTime.nextTrigger(7, 0, 1 shl 5, now) }
        assertEquals(Calendar.FRIDAY, t.get(Calendar.DAY_OF_WEEK)); assertEquals(13, t.get(Calendar.DAY_OF_MONTH))
    }

    @Test fun sameWeekdayAlreadyPassedGoesNextWeek() {
        val now = cal(2026, Calendar.NOVEMBER, 9, 9, 0) // Monday 09:00
        val t = Calendar.getInstance().apply { timeInMillis = AlarmTime.nextTrigger(7, 0, 1 shl 1, now) } // Monday only
        assertEquals(16, t.get(Calendar.DAY_OF_MONTH))
    }

    @Test fun invalidValuesAreClamped() {
        val now = cal(2026, Calendar.NOVEMBER, 9, 0, 0)
        val t = Calendar.getInstance().apply { timeInMillis = AlarmTime.nextTrigger(99, 99, 0, now) }
        assertEquals(23, t.get(Calendar.HOUR_OF_DAY)); assertEquals(59, t.get(Calendar.MINUTE))
    }
}
